import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip } from "recharts";

const API_KEY = import.meta.env.VITE_API_KEY;
const SYMBOL = "EUR/USD";
const INTERVAL = "15min";

export default function ForexAnalyzer() {
  const [priceData, setPriceData] = useState([]);
  const [signal, setSignal] = useState("Carregando...");

  useEffect(() => {
    async function fetchData() {
      try {
        const url = `https://api.twelvedata.com/ema?symbol=${SYMBOL}&interval=${INTERVAL}&time_period=20&apikey=${API_KEY}`;
        const ema20Res = await fetch(url);
        const ema20Json = await ema20Res.json();

        const ema50Url = `https://api.twelvedata.com/ema?symbol=${SYMBOL}&interval=${INTERVAL}&time_period=50&apikey=${API_KEY}`;
        const ema50Res = await fetch(ema50Url);
        const ema50Json = await ema50Res.json();

        const priceUrl = `https://api.twelvedata.com/time_series?symbol=${SYMBOL}&interval=${INTERVAL}&apikey=${API_KEY}`;
        const priceRes = await fetch(priceUrl);
        const priceJson = await priceRes.json();

        const combined = priceJson.values.map((entry, i) => ({
          time: entry.datetime.slice(11, 16),
          price: parseFloat(entry.close),
          ema20: parseFloat(ema20Json.values[i]?.ema || entry.close),
          ema50: parseFloat(ema50Json.values[i]?.ema || entry.close),
        })).reverse();

        setPriceData(combined);

        const last = combined[combined.length - 1];
        if (last.ema20 > last.ema50) {
          setSignal("📈 Sinal de COMPRA (EMA 20 acima da EMA 50)");
        } else {
          setSignal("📉 Sinal de VENDA (EMA 20 abaixo da EMA 50)");
        }
      } catch (error) {
        console.error("Erro ao buscar dados da API:", error);
        setSignal("Erro ao carregar os dados. Verifique sua conexão ou chave da API.");
      }
    }

    fetchData();
  }, []);

  return (
    <div className="p-6 grid gap-4">
      <h1 className="text-2xl font-bold">Analisador Forex - EUR/USD (M15)</h1>

      <h2 className="text-xl mb-2">{signal}</h2>
      <LineChart width={600} height={300} data={priceData}>
        <XAxis dataKey="time" />
        <YAxis domain={["auto", "auto"]} />
        <Tooltip />
        <Line type="monotone" dataKey="price" stroke="#8884d8" name="Preço" />
        <Line type="monotone" dataKey="ema20" stroke="#82ca9d" name="EMA 20" />
        <Line type="monotone" dataKey="ema50" stroke="#ff7300" name="EMA 50" />
      </LineChart>

      <button onClick={() => window.location.reload()}>🔄 Atualizar</button>
    </div>
  );
}